<div id='search'>
<div class='form'>
<form action='<?php echo home_url(); ?>/' method='get'>
<div><label>find</label>
<input class='text' name='s' onfocus='if (this.value == "search here . . .") {this.value = "";}' onblur='if (this.value == "") {this.value = "search here . . .";}' value='search here . . .' type='text'/>
<input class='reset' type='reset'/><input class="submit" value="Go" type="submit"/></div>
</form>
</div>
</div>