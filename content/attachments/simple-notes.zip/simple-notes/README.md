Simple Notes WordPress theme
===============

Simple Notes is a theme for WordPress adapted from [Nesta Theme](http://www.nurulimam.com) Designed by
[Nurul Imam](http://www.nurulimam.com)
