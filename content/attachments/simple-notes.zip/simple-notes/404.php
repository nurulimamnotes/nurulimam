<!DOCTYPE html>
<html>
<head>
<title>Please Wait...</title>
<meta http-equiv="refresh" content="0;url=<?php echo home_url()?>" /> 
</head>
<body>
<h1 style="text-align:center">Please Wait...</h1>
</body>
</html>