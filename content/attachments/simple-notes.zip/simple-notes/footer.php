<footer>
<p style="float:left;margin-left:3%">Copyright &#169; 2011 <a href="<?php echo home_url()?>" title="<?php bloginfo( 'description' ); ?>"><?php bloginfo( 'name' ); ?></a></p>
<p style="float:right;margin-right:3%">Theme designed <em>by</em> <a href="http://www.nurulimam.com/" title="Blog &amp; Note of Nurul Imam" target="_blank">Nurul Imam</a> <em>&amp;</em> Powered <em>by</em> <a href="http://wordpress.org" title="WordPress.org" target="_blank">WordPress</a></p>
</footer>
<?php wp_footer(); ?>

</body>
</html>